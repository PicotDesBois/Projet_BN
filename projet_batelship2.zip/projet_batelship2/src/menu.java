import javax.swing.*;
import java.awt.event.ComponentAdapter;

public class menu extends JFrame{
    private JPanel panelmenu;
    private JLabel picture;
/*
    public menu(){

        setLocation(400,200);
        setTitle("menu");
        setSize(450,300);
        setContentPane(panelmenu);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);


    }

    public void main (String args[]) {
        menu myFrame = new menu();
    }

 */
}
